package application;

public  class Account {
	private int userID;
	private String username;
	private String password;
	
	public int getUserID() {return userID;}
	public void setUserID(int userID) {this.userID = userID;}
	public String getUsername() {return username;}
	public void setUsername(String username) {this.username = username;}
	public String getPassword() {return password;}
	public void setPassword(String password) {this.password = password;}

	Account(){
		userID = -1;
		username = null;
		password = null;
	}

	Account(int id, String uname, String lname){
		userID = id;
		username = uname;
		password = lname;
	}
	
	public void getAccountDetails() {
		System.out.println(" => Account Details!");
		System.out.println(" => UserID: " + userID);
		System.out.println(" => Username: " + username);
		System.out.println(" => Password: " + password);
	}

	public void newRegistration(int newID,String recUsername, String recPassword) {
		userID = newID;
		username = recUsername;
		password = recPassword;
		System.out.println(" => New Account has been created!");
		getAccountDetails();
	}

	public void Login(int ID, String recUsername) {
		System.out.println(" => " + recUsername + " has currently logged in with ID: " + ID);
	}
	
	public void deleteAccount() {
		userID = -1;
		username = null;
		password = null;
	}	
}



