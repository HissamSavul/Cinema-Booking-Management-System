package application;

public class Booking {
	private int bookingID;
	private int movieID;
	private int customerID;
	private int bookedTicketsQuantity;
	private int screenID;
	
	Booking(){
		setBookingID(-1);
		setMovieID(-1);
		setBookedTicketsQuantity(-1);
		setCustomerID(-1);
		setScreenID(-1);
	}
	public int getScreenID() {return screenID;}
	public void setScreenID(int screenID) {this.screenID = screenID;}
	public int getCustomerID() {return customerID;}
	public void setCustomerID(int customerID) {this.customerID = customerID;}
	public int getBookingID() {return bookingID;}
	public void setBookingID(int bookingID) {this.bookingID = bookingID;}
	public int getMovieID() {return movieID;}
	public void setMovieID(int movieID) {this.movieID = movieID;}
	public int getBookedTicketsQuantity() {return bookedTicketsQuantity;}
	public void setBookedTicketsQuantity(int bookedTicketsQuantity) {this.bookedTicketsQuantity = bookedTicketsQuantity;}
	
	public void getBookingDetails() {
		System.out.println(" => Booking Details!");
		System.out.println(" => Booking ID: " + bookingID);
		System.out.println(" => Movie ID: " + movieID);
		System.out.println(" => screen ID: " + movieID);
		System.out.println(" => Customer ID: " + customerID);
		System.out.println(" => Tickets Booked: " + bookedTicketsQuantity);
	}
	
	public void makeBooking(int a, int b, int c, int d, int e) {
		setBookingID(a);
		setMovieID(b);
		setBookedTicketsQuantity(c);
		setCustomerID(d);
		setScreenID(e);
	}
	
	public void cancelBooking() {
		setBookingID(-1);
		setMovieID(-1);
		setBookedTicketsQuantity(-1);
		setCustomerID(-1);
		setScreenID(-1);
	}
	
}
