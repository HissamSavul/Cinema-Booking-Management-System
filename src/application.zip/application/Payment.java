package application;

public class Payment {
	private int paymentID;
	private int amount;
	private int bookingID;

	Payment(){
		setPaymentID(-1);
		setAmount(-1);
		setPaymentID(-1);
	}

	public int getBookingID() {return bookingID;}
	public void setBookingID(int bookingID) {this.bookingID = bookingID;}
	public int getPaymentID() {return paymentID;}
	public void setPaymentID(int paymentID) {this.paymentID = paymentID;}
	public int getAmount() {return amount;}
	public void setAmount(int amount) {this.amount = amount;}
	
	public void getPaymentDetails() {
		System.out.println(" => Payment Details!");
		System.out.println(" => Payment ID: " + paymentID);
		System.out.println(" => Amount Paid: " + amount + " Rs");
	}
	
	public void makePayment(int pid, int am, int bid) {
		paymentID = pid;
		amount = am;
		bookingID = bid;
		getPaymentDetails();
	}
	
}

