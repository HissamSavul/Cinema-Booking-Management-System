package application;
import java.util.ArrayList;

public class Movie {
	private ArrayList<Integer> movieIDList;
	private MovieDescription movieDesc;
	private ArrayList<Screening> movieScreening;
	private int totalScreenings;
	
	Movie(){
		movieIDList = new ArrayList<Integer>();
		movieDesc = null;
		setMovieScreening(null);
		totalScreenings = -1;
	}
	
	public ArrayList<Integer> getMovieIDList() {return movieIDList;}
	public void setMovieIDList(ArrayList<Integer> movieIDList) {this.movieIDList = movieIDList;}
	public MovieDescription getMovieDesc() {return movieDesc;}
	public void setMovieDesc(MovieDescription movieDesc) {this.movieDesc = movieDesc;}
	public int getTotalScreenings() {return totalScreenings;}
	public void setTotalScreenings(int totalScreenings) {this.totalScreenings = totalScreenings;}
	public ArrayList<Screening> getMovieScreening() {return movieScreening;}
	public void setMovieScreening(ArrayList<Screening> movieScreening) {this.movieScreening = movieScreening;}
	
	public void getMovies() {
		for(int i=0; i<movieIDList.size() ; i++) {
			System.out.println(" => Movie #" + i + ": " + movieIDList.get(i));		
			if(movieIDList.get(i) == movieDesc.getMovieID())
				movieDesc.getMovieDescriptionSetails();
			if(movieIDList.get(i) == movieScreening.get(i).getMovID()) {
				for(int j=0 ; j<totalScreenings; j++) {
					System.out.println(" => Screening #" + j);		
					movieScreening.get(i).getScreeningDetails();
				}
			}
		}	
	}

	//customer
	public void searchMovie() {
		
	}
	
	//manager
	public void addMovie(int ID, String title, String duration, String genre, String image) {
		movieIDList.add(ID);
		movieDesc = new MovieDescription(); 
		movieDesc.setMovieID(ID);
		movieDesc.setTitle(title);
		movieDesc.setDuration(duration);
		movieDesc.setGenre(genre);
		movieDesc.setImage(image);
		System.out.println(" => New Movie has been added!");
		//getMovies();
	}
	
	public void removeMovie() {
		
	}

}
