package application;

public class Credit {
	private int customerID;
	private int accNum;
	private int balance;
	private int cvv;
	
	Credit(){
		setCustomerID(-1);
		setAccNum(-1);
		setBalance(0);
		setCvv(-1);
	}

	public int getCustomerID() {return customerID;}
	public void setCustomerID(int customerID) {this.customerID = customerID;}
	public int getAccNum() {return accNum;}
	public void setAccNum(int accNum) {this.accNum = accNum;}
	public int getBalance() {return balance;}
	public void setBalance(int balance) {this.balance = balance;}
	public int getCvv() {return cvv;}
	public void setCvv(int cvv) {this.cvv = cvv;}
	
	public void getCreditDetails() {
		System.out.println(" => Credit Details!");
		System.out.println(" => Customer ID: " + customerID);
		System.out.println(" => Account Number: " + accNum);
		System.out.println(" => Balance: " + balance);
		System.out.println(" => CVV: " + cvv);
	}
	
	public void updateCredit(int bal) {
		balance -= bal;
	}
}
