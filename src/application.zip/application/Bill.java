package application;

public class Bill {

}
