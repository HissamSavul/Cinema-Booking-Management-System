package application;

public class Screening {
	private int movID;
	private String title;
	private int screeningID;
	private String date;
	private String time;
	private int totalSeats;
	
	Screening(){
		setTitle(null);
		setScreeningID(-1);
		setDate(null);
		setTime(null);
		setTotalSeats(50);
		setMovID(-1);
	}

	public int getMovID() {return movID;}
	public void setMovID(int movID) {this.movID = movID;}
	public String getTitle() {return title;}
	public void setTitle(String title) {this.title = title;}
	public int getScreeningID() {return screeningID;}
	public void setScreeningID(int screeningID) {this.screeningID = screeningID;}
	public String getDate() {return date;}
	public void setDate(String date) {this.date = date;}
	public String getTime() {return time;}
	public void setTime(String time) {this.time = time;}
	public int getTotalSeats() {return totalSeats;}
	public void setTotalSeats(int totalSeats) {this.totalSeats = totalSeats;}
	
	public void getScreeningDetails() {
		System.out.println(" => Screening Details!");
		System.out.println(" => Movie Title: " + title);
		System.out.println(" => Movie ID: " + movID);
		System.out.println(" => Screening ID: " + screeningID);
		System.out.println(" => Date: " + date);
		System.out.println(" => Time: " + time);
		System.out.println(" => Available Seats: " + totalSeats);
	}
	
	public void addScreening(int screenid, String rdate, String rtime, int seats, String movie, int movid) {
		movID = movid;
		title = movie;
		screeningID = screenid;
		date = rdate;
		time = rtime;
		totalSeats = seats;
		getScreeningDetails();
	}
	
	public void removeScreening() {
		movID = -1;
		title = null;
		screeningID = -1;
		date = null;
		time = null;
		totalSeats = -1;
		getScreeningDetails();
	}
	
	
}
